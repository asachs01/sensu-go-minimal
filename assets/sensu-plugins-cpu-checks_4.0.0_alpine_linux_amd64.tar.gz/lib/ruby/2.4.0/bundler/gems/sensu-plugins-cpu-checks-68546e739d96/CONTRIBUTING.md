[Development Documentation](http://sensu-plugins.io/docs/developer_guidelines.html)
