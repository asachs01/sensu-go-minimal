require 'sensu-plugins-cpu-checks/version'
require 'sensu-plugins-cpu-checks/common_interrupts'
